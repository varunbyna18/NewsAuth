const logger = require("../utils/logger");

/**
 * Error handler middleware
 */
function errorHandler(err, req, res, next) {
  logger.error("API Error", {
    message: err.message,
    path: req.path,
    method: req.method,
    status: err.status || 500
  });

  const status = err.status || 500;
  const message = err.message || "Internal Server Error";

  res.status(status).json({
    error: {
      status,
      message,
      timestamp: new Date().toISOString()
    }
  });
}

/**
 * 404 handler middleware
 */
function notFoundHandler(req, res) {
  res.status(404).json({
    error: {
      status: 404,
      message: "Route not found",
      path: req.path
    }
  });
}

/**
 * Request logging middleware
 */
function requestLogger(req, res, next) {
  logger.debug(`${req.method} ${req.path}`, { ip: req.ip });
  next();
}

module.exports = {
  errorHandler,
  notFoundHandler,
  requestLogger
};
